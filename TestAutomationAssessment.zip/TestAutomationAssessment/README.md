# README FOR AUTOMATION(Vodacom)


This readMe file only contains few very important things that is needed to execute the project- I didnot write alot of things because of limited time

### Project Structure? ###

* The Report is found at target/Reports
* The Screenshots are found at target/Screenshots

### How to execute ###
* You need to run the testng.xml file so that tests can generate the report