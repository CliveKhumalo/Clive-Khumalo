package Extentreport;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

import java.io.File;

public class ExtentReportsManager {

    private static ExtentReports extentReports;
    private static ExtentSparkReporter sparkReporter;
    private static String reportPath = System.getProperty("user.dir");

    public static ExtentReports ExtentSetup()
    {
        extentReports = new ExtentReports();
        sparkReporter = new ExtentSparkReporter(new File(reportPath + "/target/Reports/ExtentReport.html"));
        extentReports.attachReporter(sparkReporter);

        sparkReporter.config().setDocumentTitle("Extent Report");
        sparkReporter.config().setTheme(Theme.DARK);
        sparkReporter.config().setReportName("Vodacom Report");

        extentReports.setSystemInfo("Browser", "chrome");
        extentReports.setSystemInfo("OS", System.getProperty("os.name"));
        extentReports.setSystemInfo("URL", "https://www.vodacom.co.za/");
        extentReports.setSystemInfo("Execution Machine", System.getProperty("user.name"));



        return extentReports;
    }

}
