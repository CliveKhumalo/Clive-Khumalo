package PageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

public class DealsDetails {

    WebDriver driver = null;

    @FindBy(xpath = "//h1[contains(@id,'heading-Deal details')]")
    private WebElement DetailsLabel;

    @FindBy(xpath = "//div[@class='DealDetailFooterTop_details-label__2NcNB pl-m col-md-4 col-6'][contains(.,'Deal price:')]")
    private WebElement DealPrice;

    @FindBy(xpath = "//div[@class='DealDetailFooterTop_details-label__2NcNB pl-m col-md-4 col-6'][contains(.,'Contract duration:')]")
    private WebElement ContractDuration;

    @FindBy(xpath = "//div[@class='DealDetailFooterTop_details-label__2NcNB pl-m col-md-4 col-6'][contains(.,'Available online:')]")
    private WebElement AvailableOnline;

    @FindBy(xpath = "//button[@type='button'][contains(.,'Get this deal')]")
    private WebElement GetThisDealButton;



    public DealsDetails(WebDriver driver) {
        this.driver = driver;
    }

    public DealsDetails validateDealsDetailsScreen()  {
        new WebDriverWait(driver, 30).until(ExpectedConditions.visibilityOf(DetailsLabel));
        DetailsLabel.isDisplayed();

        return this;
    }

    public DealsDetails validateDealDetails()  {

        Assert.assertEquals(DealPrice.getText(),"Deal price:");

        return this;
    }
    public DealsDetails validateDealDetailsFail()  {

        Assert.assertEquals(DealPrice.getText(),"FailDeal price:");

        return this;
    }

    public DealsDetails validateContractDuration()  {

        Assert.assertEquals(ContractDuration.getText(),"Contract duration:");

        return this;
    }

    public DealsDetails validateAvailableOnline()  {

        Assert.assertEquals(AvailableOnline.getText(),"Available online:");

        return this;
    }

    public DealsDetails clickGetThisDeal()  {

        GetThisDealButton.click();

        return this;
    }
}
