package PageObjects;

import org.openqa.selenium.Cookie;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.asserts.SoftAssert;

public class HomePage {

    WebDriver driver = null;

    @FindBy(id = "hotspot-portlet-card-content-cta---3293947340-1")
    private WebElement sumsung;

    @FindBy(id = "hotspot-portlet-card-content-cta---3293947340-3")
    private WebElement redMiNote;

    @FindBy(xpath = "//a[contains(.,'Personal')]")
    private WebElement personal;

    @FindBy(id = "onetrust-accept-btn-handler")
    private WebElement cokies;

    @FindBy(id = "onetrust-accept-btn-handler")
    private WebElement deviceNameHome;

    @FindBy(xpath = "//a[@href='/'][contains(.,'Home')]")
    private WebElement returnHome;



    public HomePage(WebDriver driver) {
        this.driver = driver;
    }

    public HomePage acceptCookies() throws InterruptedException {
        Thread.sleep(5000);
        cokies.click();

        return this;
    }

    public HomePage verifyHomePage() {
        new WebDriverWait(driver, 30).until(ExpectedConditions.visibilityOf(personal));

        personal.isDisplayed();

        return this;
    }


    public HomePage clickBuy() {
        new WebDriverWait(driver, 30).until(ExpectedConditions.visibilityOf(sumsung));

        sumsung.click();

        return this;
    }

    public HomePage clickBuy_Redmi() {
        new WebDriverWait(driver, 30).until(ExpectedConditions.visibilityOf(redMiNote));
        redMiNote.click();

        return this;
    }

    public HomePage returnHomePage() {
        returnHome.click();

        return this;
    }


}
