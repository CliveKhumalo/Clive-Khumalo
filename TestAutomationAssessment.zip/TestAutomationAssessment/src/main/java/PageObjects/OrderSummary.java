package PageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

public class OrderSummary {

    WebDriver driver = null;

    @FindBy(xpath = "//p[contains(.,'Order summary')]")
    private WebElement OrderSumamryLabel;

    @FindBy(xpath = "(//p[contains(.,'Device')])[1]")
    private WebElement Device;

    @FindBy(xpath = "//p[contains(.,'Plan')]")
    private WebElement Plan;

    @FindBy(xpath = "(//p[contains(.,'Contract cover')])[1]")
    private WebElement ContractCover;


    public OrderSummary(WebDriver driver) {
        this.driver = driver;
    }


    public OrderSummary validateOrderSummaryScreen() {
        new WebDriverWait(driver, 30).until(ExpectedConditions.visibilityOf(OrderSumamryLabel));
        OrderSumamryLabel.isDisplayed();

        return this;
    }

    public OrderSummary validateDeviceField() {
        Assert.assertEquals(Device.getText(), "Device");

        return this;
    }

    public OrderSummary validatePlanField() {
        Assert.assertEquals(Plan.getText(), "Plan");

        return this;
    }

    public OrderSummary validateContractCoverField() {
        Assert.assertEquals(ContractCover.getText(), "Contract cover");

        return this;
    }
}
