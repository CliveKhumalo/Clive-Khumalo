package Tests;

import PageObjects.DealsDetails;
import PageObjects.HomePage;
import PageObjects.OrderSummary;
import Utils.BrowserFactory;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public class BaseTest {

    BrowserFactory browserFactory = new BrowserFactory();
    final WebDriver driver = browserFactory.startBrowser("chrome"," https://www.vodacom.co.za/");
    HomePage homePage = PageFactory.initElements(driver, HomePage.class);
    DealsDetails dealsDetails = PageFactory.initElements(driver, DealsDetails.class);
    OrderSummary orderSummary = PageFactory.initElements(driver, OrderSummary.class);
}
