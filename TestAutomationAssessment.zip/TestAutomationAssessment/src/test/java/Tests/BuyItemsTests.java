package Tests;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import java.io.File;
import java.io.IOException;

public class BuyItemsTests extends BaseTest {

    @Test
    public void testScenario1Steps() throws InterruptedException {
        Thread.sleep(2000);
        takeSnapshot(driver,"Home Screen");
        homePage
                .acceptCookies()
                .verifyHomePage()
                .clickBuy();
        dealsDetails
                .validateDealsDetailsScreen()
                .validateDealDetails()
                .validateContractDuration()
                .validateAvailableOnline()
                .clickGetThisDeal();
        takeSnapshot(driver,"Deals Details");
        orderSummary
                .validateOrderSummaryScreen()
                .validateDeviceField()
                .validatePlanField()
                .validateContractCoverField();
        takeSnapshot(driver,"Salary Screen");
    }

    @Test
    public void testScenario2Steps() {
        homePage
                .returnHomePage()
                .verifyHomePage()
                .clickBuy_Redmi();
        dealsDetails
                .validateDealsDetailsScreen()
                .validateDealDetailsFail();

    }

    public void takeSnapshot(WebDriver driver, String screenShotname) {

        TakesScreenshot ts = (TakesScreenshot) driver;
        File src = ts.getScreenshotAs(OutputType.FILE);

        String path = System.getProperty("user.dir") + "/target/Screenshots/" + screenShotname + ".png";

        File destination = new File(path);

        try {
            FileUtils.copyFile(src, destination);
        } catch (IOException e) {
            System.out.println("Screenshot Capture Failed" + e.getMessage());
        }

    }


    @AfterTest
    public void closeBrowser() {
        driver.quit();
    }
}
